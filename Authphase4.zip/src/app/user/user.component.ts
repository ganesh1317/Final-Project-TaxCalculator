import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms'
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { AuthService } from '../service/auth.service';
import { MatDialog } from '@angular/material/dialog';
import { UpdatepopupComponent } from '../updatepopup/updatepopup.component'
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements AfterViewInit {
element: any;
updateuser(arg0: any) {
throw new Error('Method not implemented.');
}
addEmployee() {
  this.addEmployee(); {
    if(this.haveadd){
      this.toastr.success('Successfully Added..!')
   }else{
     this.toastr.warning("You don't have access for Create")
   }
  }
throw new Error('Method not implemented.');
}



  constructor(
    private builder: FormBuilder, 
    private service: AuthService, 
    private dialog: MatDialog,
    private toastr:ToastrService,
    private router: Router) {
    this.LoadEmployee();
    this.SetAccesspermission();
  }
  employeelist: any;
  dataSource: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  accessdata: any;
  haveedit = false;
  haveadd = false;
  havedelete = false;


  ngAfterViewInit(): void {

  }
  LoadEmployee() {
    this.service.Getall().subscribe(res => {
      this.employeelist = res;
      this.dataSource = new MatTableDataSource(this.employeelist);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  SetAccesspermission() {
    this.service.Getaccessbyrole(this.service.getrole(), 'customer').subscribe(res => {
      this.accessdata = res;
      console.log(this.accessdata);

      if(this.accessdata.length>0){
        this.haveadd=this.accessdata[0].haveadd;
        this.haveedit=this.accessdata[0].haveedit;
        this.havedelete=this.accessdata[0].havedelete;
        this.LoadEmployee();
      }else{
        alert('you are not authorized to access.');
        this.router.navigate(['']);
      }
    });
  }
    

  displayedColumns: string[] = ['username', 'name', 'email', 'status', 'role', 'action'];

  // updateemployee(code: any) {

  //   if(this.haveedit){
  //      this.toastr.success('Successfully Updated..!')
  //   }else{
  //     this.toastr.warning("You don't have access for Edit")
  //   }

  // }


  removeemployee(code: any) {
    if(this.havedelete){
      this.toastr.success('Successfully Removed..!')
   }else{
     this.toastr.warning("You don't have access for Delete")
   }
  }

  updateEmployee(code: any) {
    this.OpenDialog('1000ms', '600ms', code);
  }

  OpenDialog(enteranimation: any, exitanimation: any, code: string) {
    const popup = this.dialog.open(UpdatepopupComponent, {
      enterAnimationDuration: enteranimation,
      exitAnimationDuration: exitanimation,
      width: '30%',
      data: {
        usercode: code
      }
    });
    popup.afterClosed().subscribe(res => {
      this.LoadEmployee();
    });
  }
}


