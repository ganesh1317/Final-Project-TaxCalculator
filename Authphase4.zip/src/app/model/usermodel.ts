export interface usermodel{

}